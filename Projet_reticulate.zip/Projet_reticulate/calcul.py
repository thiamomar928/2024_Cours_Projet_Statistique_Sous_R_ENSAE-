# -*- coding: utf-8 -*-
"""
Created on Sat Mar 16 09:42:16 2024

@author: Asus 10TH Gen
"""


def addition(a, b):
    return a + b